ls . | wc -l

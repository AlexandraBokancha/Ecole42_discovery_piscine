#!/bin/bash
echo "$1"
echo "$2"
echo "$3"
